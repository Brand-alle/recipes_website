from flask import render_template, request, redirect, session, flash
from flask_app import app
from flask_app.models.user import User
from flask_app.models.recipe import Recipe
import re
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)


@app.route("/recipe_wall")
def recipe_wall():
    if "user_id" not in session:
        return redirect("/logout")
    print(session["user_id"])
    user = User.get_by_id(session["user_id"])
    users = User.get_all() 
    recipes = Recipe.get_all_recipes()
    return render_template("recipe_wall.html", user=user, users=users, recipes=recipes)


@app.route("/recipes/new")
def recipesnew():
    return render_template("new_recipe.html")


@app.route("/recipes/new/save", methods=["POST"])
def saverecipe():
    valid_recipe = Recipe.validate_recipe(request.form)
    if 'user_id' not in session:
        return redirect('/')
    if not valid_recipe:
        return redirect("/recipes/new")
    data ={ "name":request.form["name"],
        "description":request.form["description"],
        "instructions":request.form["instructions"],
        "date_cooked":request.form["date_cooked"],
        "under_30":request.form["under_30"],
        "user_id":session["user_id"]
    }
    Recipe.save(data)
    return redirect("/recipe_wall")



@app.route("/recipes/edit/<int:recipe_id>")
def editrecipe(recipe_id):
    if "user_id" not in session:
        return redirect("/logout")
    recipe_id = {"id":recipe_id}
    recipe = Recipe.get_by_id(recipe_id)
    return render_template("edit_recipe.html", recipe = recipe)

# @app.route("/read/edit/<int:id>")
# def edit(id):
#     data = {"id":id}
#     return render_template("edit_user.html", user=User.get_one(data))

@app.route("/recipes/update/<int:recipe_id>",methods=["POST"])
def update(recipe_id):
    valid_recipe = Recipe.validate_recipe(request.form)
    if 'user_id' not in session:
        return redirect('/')
    if not valid_recipe:
        return redirect(f"/recipes/edit/{recipe_id}")
    data ={ "id":recipe_id,
        "name":request.form["name"],
        "description":request.form["description"],
        "instructions":request.form["instructions"],
        "date_cooked":request.form["date_cooked"],
        "under_30":request.form["under_30"],
    }
    Recipe.update(data)
    return redirect("/recipe_wall")


@app.route("/recipes/view/<int:recipe_id>")
def viewrecipe(recipe_id):
    if "user_id" not in session:
        return redirect("/logout")
    user = User.get_by_id(session["user_id"])
    recipe_id = {"id":recipe_id}
    recipe = Recipe.get_by_id(recipe_id)
    return render_template("view_recipe.html", recipe = recipe, user=user)

@app.route("/recipes/delete/<int:recipe_id>")
def deleterecipe(recipe_id):
    if "user_id" not in session:
        return redirect("/logout")
    data = {
        "id" : recipe_id
    }
    Recipe.delete(data)
    return redirect("/recipe_wall")


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")