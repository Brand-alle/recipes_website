# import the function that will return an instance of a connection
from flask_app.config.mysqlconnection import connectToMySQL
from datetime import datetime
from flask_app.models import user
from flask import flash, session
import re	# the regex module
# create a regular expression object that we'll use later
import math 
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 

class Recipe:
    db = "recipes_schema"
    def __init__(self,db_data):
        self.id = db_data["id"]
        self.name = db_data["name"]
        self.description = db_data["description"]
        self.instructions = db_data["instructions"]
        self.date_cooked = db_data["date_cooked"]
        self.under_30 = db_data["under_30"]
        self.created_at = db_data["created_at"]
        self.updated_at = db_data["updated_at"]
        self.user_id = db_data["user_id"]
        # None can represent a currently empty space for a single User dictionary to be placed here, as a Tweet is made by ONE User. We want a User instance and all their attributes to be placed here, so something like data['...'] will not work as we have to make the User instance ourselves.
        self.creator = None


    @classmethod
    def get_all(cls):
        query = "SELECT * FROM recipes;"
        recipe_data = connectToMySQL(cls.db).query_db(query)
        recipes = []
        for recipe in recipe_data:
            recipes.append( cls(recipe) )
        return recipes


    @classmethod
    def get_by_id(cls,recipe_id):
        query ="SELECT * FROM recipes LEFT JOIN users on recipes.user_id = users.id WHERE recipes.id = %(id)s"
        results = connectToMySQL(cls.db).query_db(query,recipe_id)
        recipe = cls(results[0])
        for row in results:
            if row["users.id"] == None:
                break
            user_data = {
                "id": row["users.id"],
                "first_name": row["first_name"],
                "last_name": row["last_name"],
                "email": row["email"],
                "password": "",
                "created_at": row["users.created_at"],
                "updated_at": row["users.updated_at"]
            }
            # author.favorite_books.append(book.Book(data))
            recipe.creator = user.User(user_data)
        return recipe


    @classmethod
    def get_all_recipes(cls):
        query = "SELECT * FROM recipes JOIN users on recipes.user_id = users.id;"
        results = connectToMySQL(cls.db).query_db(query)
        print(results)
        # all_the_messages = cls(results[0])
        all_recipes = []
        for row in results:
            # Create a Tweet class instance from the information from each db row
            one_recipe = cls(row)
            # Any fields that are used in BOTH tables will have their name changed, which depends on the order you put them in the JOIN query, use a print statement in your classmethod to show this.
            user_data = {
                "id": row["users.id"],
                "first_name": row["first_name"],
                "last_name": row["last_name"],
                "email": row["email"],
                "password": "",
                "created_at": row["users.created_at"],
                "updated_at": row["users.updated_at"]
            }
            # Create the User class instance that's in the user.py model file
            owner = user.User(user_data)
            # Associate the Tweet class instance with the User class instance by filling in the empty creator attribute in the Tweet class
            one_recipe.creator = owner
            # Append the Tweet containing the associated User to your list of tweets
            all_recipes.append(one_recipe)
        return all_recipes




    @classmethod
    def save(cls, data):
        query = "INSERT INTO recipes (name, description, instructions, date_cooked, under_30, created_at, user_id) VALUES ( %(name)s , %(description)s, %(instructions)s, %(date_cooked)s, %(under_30)s, NOW(), %(user_id)s);"
        # data is a dictionary that will be passed into the save method from server.py
        endresult = connectToMySQL(cls.db).query_db(query, data)
        return endresult

    @classmethod
    def update(cls, data):
        query = "UPDATE recipes SET name = %(name)s, description=%(description)s, instructions=%(instructions)s, date_cooked=%(date_cooked)s, under_30=%(under_30)s WHERE id = %(id)s;"
        # data is a dictionary that will be passed into the save method from server.py
        endresult = connectToMySQL(cls.db).query_db(query, data)
        return endresult

    @classmethod
    def delete(cls,data):
        query  = "DELETE FROM recipes WHERE recipes.id = %(id)s;"
        return connectToMySQL(cls.db).query_db(query, data)

    @staticmethod
    def validate_recipe(recipe):
        is_valid = True # we assume this is true
        if len(recipe['name']) < 3:
            flash("Recipe Name must be at least 3 characters long!", "newrecipe")
            is_valid = False
        if len(recipe['description']) < 3:
            flash("Recipe Description must be at least 3 characters long!", "newrecipe")
            is_valid = False
        if len(recipe['instructions']) < 3:
            flash("Recipe Instructions must be at least 3 characters long!", "newrecipe")
            is_valid = False
        if recipe['date_cooked'] == '':
            flash("Recipe must have a cook/made date!", "newrecipe")
            is_valid = False
        if "under_30" not in recipe:
            flash("Under 30 determination required!", "newrecipe")
            is_valid = False
        return is_valid


    def time_span(self):
        print(self.created_at)
        now = datetime.now()
        delta = now - self.created_at
        print(delta.days)
        print(delta.total_seconds())
        if delta.days > 0:
            return f"{delta.days} days ago"
        elif (math.floor(delta.total_seconds() / 60)) >= 60:
            return f"{math.floor(math.floor(delta.total_seconds() / 60)/60)} hours ago"
        elif delta.total_seconds() >= 60:
            return f"{math.floor(delta.total_seconds() / 60)} minutes ago"
        else:
            return f"{math.floor(delta.total_seconds())} seconds ago"